import React, { useState } from "react";
import axios from 'axios'
import swal from 'sweetalert';

const AddUserForm = props => {
    // const initialFormState = { name: "", under_group_name: "" };
    const [item, setItem] = useState(
        {
            name: "",
            item_group_id: ""
        }
    );

    const handleInputChange = event => {
        const { name, value } = event.target;
        setItem({ ...item, [name]: value });
    };
    console.log('sagar', item);
    return (

        <form
            onSubmit={event => {
                event.preventDefault();
                if (!item.name || !item.item_group_id) return;
                axios.post('https://uditsolutions.in/vinrajbackend/public/api/items', item)
                    .then(() => {
                        console.log("swal")
                        swal("Successfully Created Item !")
                            .then(() => {
                                window.location.reload();
                            })
                    })
                    .catch(
                        error => console.log(error)
                    )
                // props.addUser(user);
                // setUser(initialFormState);
            }}
        >
            <div className="form-row" style={{ fontSize: "12px" }}>

                <div className="form-group col-md-4">
                    <label htmlFor="inputPassword4"> Name </label>
                    <input type="text" className="form-control" id="inputPassword4" placeholder="" value={item.name} name="name" onChange={handleInputChange} />
                </div>
                <div className="form-group col-md-4">
                    <label htmlFor="inputPassword4">User Item Group id</label>
                    <input type="text" className="form-control" id="inputPassword4" placeholder="" value={item.item_group_id} name="item_group_id" onChange={handleInputChange} />
                </div>
                <div className="form-group col-md-4 mt-4">
                    <button className="btn btn-primary" type="submit" >Add</button>
                </div>

            </div>

        </form>
    );
};

export default AddUserForm;
