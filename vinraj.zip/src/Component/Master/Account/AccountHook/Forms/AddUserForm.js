import React, { useState } from "react";
import axios from 'axios'
import swal from 'sweetalert';

const AddUserForm = props => {
    // const initialFormState = { name: "", under_group_name: "" };
    const [user, setUser] = useState(
        {
            name:"",
            account_group_id:""
        }
    );

    const handleInputChange = event => {
        const { name, value } = event.target;
        setUser({ ...user, [name]: value });
    };
    console.log('sagar',user);
    return (
        
        <form
            onSubmit={event => {
                event.preventDefault();
                if (!user.name || !user.account_group_id) return;
                    axios.post('https://uditsolutions.in/vinrajbackend/public/api/accounts',user)
                    .then(()=>{
                        console.log("swal")
                        swal("Successfully Created Account Group!")
                        .then(() => {
                            window.location.reload();
                        })
                    })
                    .catch(
                       error=> console.log(error)
                    )
                // props.addUser(user);
                // setUser(initialFormState);
            }}
        >
            <div className="form-row" style={{ fontSize: "12px" }}>

                <div className="form-group col-md-4">
                    <label htmlFor="inputPassword4"> Name </label>
                    <input type="text" className="form-control" id="inputPassword4" placeholder="" value={user.name} name="name" onChange={handleInputChange} />
                </div>
                <div className="form-group col-md-4">
                    <label htmlFor="inputPassword4">User Account single</label>
                    <input type="number" className="form-control" id="inputPassword4" placeholder="" value={user.account_group_id} name="account_group_id" onChange={handleInputChange} />
                </div>
                 <div className="form-group col-md-4 mt-4">
                 <button className="btn btn-primary " type="submit" >Add</button>
                </div>   

            </div>
        
        </form>
    );
};

export default AddUserForm;
