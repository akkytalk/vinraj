import React, { Fragment, useState } from 'react'
import Sidebar from '../Home/Sidebar'
// import Aside from '../Home/Aside'
import Header from '../Home/Header'

import Req from './Req'


const Purchase = () => {


    return (

        <Fragment>
             <Header/>
            
             <Sidebar/> 
            <div className="content-wrapper">
                <section className="content">
                    <div className="container-fluid">
                        {/* Content Header (Page header) */}
                        <section className="content-header">

                            <ol className="breadcrumb">
                                <li><a href="#"><i className="fa fa-dashboard" /> Purchase</a></li>
                                {/* <li><a href="#"></a></li>
                            <li className="active">Data tables</li> */}
                            </ol>
                            <br />
                        </section>
                        <section className="content">
                            <div className="row">
                                <div className="col-xs-12">
                                    {/* /.box */}
                                    <div className="box">
                                        <div className="box-header">
                                            <h3 className="box-title">Purchase  Requistion</h3>

                                        </div>
                                        {/* /.box-header */}
                                        <div className="box-body">
                                            <div className="col-md-9">

                                                <Req />
                                            </div>

                                        </div>


                                    </div>

                                </div>

                            </div>

                        </section>

                    </div>
                </section>
            </div>

        </Fragment >
    )
}

export default Purchase