import React, { Fragment } from 'react'
import Home from './Component/Home/Home'
import {HashRouter as Router, Route,Switch} from 'react-router-dom'
import Master from './Component/Master/Master'
import Main from './Component/Maintaince/Maintain'
import Accgrp from './Component/Master/Account/AccGr'
import Account from './Component/Master/Account/Account'
import Purchase from './Component/Purchase/Purchase'
import ItemGrp from './Component/Master/Item/ItemGrp'
import Item from './Component/Master/Item/Item'
import Login from './Component/Auth/Login'
import Prefixm from './Component/Master/Prefix/Prefixm'
const App=()=>
{
  return(
    <Fragment>
       <Router>
         <Switch>
           {/* <Route exact path ="/"  component={Login}/> */}
           <Route exact path= "/" component={Home}/>
           <Route path="/purchase" component={Purchase}/>
           <Route path ="/equip" component={Main}/>
           <Route path="/prefix" component={Prefixm}/>
           <Route path="/master" component={Master}/>
           <Route path="/accgrp" component={Accgrp}/>
           <Route path ="/acc" component={Account}/>
           <Route path ="/itemgrp" component={ItemGrp}/>
           <Route path ="/item" component={Item}/>
         </Switch>
       </Router>
    </Fragment>
  )
}


export default App